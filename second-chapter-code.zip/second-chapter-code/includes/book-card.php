<?php
if (!isset($book)) {
    return;
}

$bookId = (int)($book['book_id'] ?? 0);
$title = $book['title'] ?? 'Untitled Book';
$university = $book['short_name'] ?? 'SC';
$module = $book['module_code'] ?? $book['category_name'] ?? 'Textbook';
$city = $book['city'] ?? '';
$province = $book['province'] ?? '';
$condition = $book['condition_grade'] ?? 'Good';
$status = $book['status'] ?? 'available';
$price = $book['price'] ?? 0;
$imagePath = $book['image_path'] ?? '';

$hasImage = !empty($imagePath) && file_exists(__DIR__ . '/../' . $imagePath);

$statusLabel = ucfirst($status);
?>

<article class="book-card" data-cursor="listing">
    <a class="book-card-link" href="<?= BASE_URL ?>book-details.php?id=<?= $bookId ?>">

        <div class="book-cover-wrap">
            <span class="card-bookmark"></span>

            <?php if ($hasImage): ?>
                <img
                    class="book-image"
                    src="<?= BASE_URL . clean($imagePath) ?>"
                    alt="<?= clean($title) ?>"
                >
            <?php else: ?>
                <div class="book-cover">
                    <span>
                        <?= clean($title) ?>
                        <small><?= clean($university) ?></small>
                    </span>
                </div>
            <?php endif; ?>

            <span class="listing-search-icon">
                <i class="bi bi-search"></i>
            </span>
        </div>

        <div class="book-info">
            <h3><?= clean($title) ?></h3>

            <div class="meta">
                <span><?= clean($university) ?></span>
                <span>•</span>
                <span><?= clean($module) ?></span>
            </div>

            <?php if ($city || $province): ?>
                <p class="book-location">
                    <?= clean(trim($city . ', ' . $province, ', ')) ?>
                </p>
            <?php endif; ?>

            <div class="price-row">
                <span class="pill"><?= clean($condition) ?></span>
                <span class="rating">
                    <i class="bi bi-star-fill"></i> 4.8
                </span>
            </div>

            <div class="price-row">
                <span class="price"><?= money($price) ?></span>
                <span class="pill status-pill"><?= clean($statusLabel) ?></span>
            </div>
        </div>

    </a>
</article>
