<?php

/* ── The only email address that may hold admin privileges ──── */
define('ADMIN_EMAIL', 'admin@secondchapter.com');

function clean($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect($path) {
    header('Location: ' . BASE_URL . ltrim($path, '/'));
    exit();
}

function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function is_admin() {
    /* Must have role=admin AND be the locked-down admin email */
    return isset($_SESSION['role'], $_SESSION['email'])
        && strtolower((string)$_SESSION['role'])  === 'admin'
        && strtolower((string)$_SESSION['email']) === strtolower(ADMIN_EMAIL);
}

function require_login() {
    if (!is_logged_in()) {
        $_SESSION['flash'] = ['type' => 'warning', 'message' => 'Please log in first.'];
        redirect('login.php');
    }
}

function require_admin() {
    if (!is_admin()) {
        $_SESSION['flash'] = ['type' => 'danger', 'message' => 'You do not have permission to access the Admin Office.'];
        redirect('login.php');
    }
}

function flash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function active_link($file) {
    return basename($_SERVER['PHP_SELF']) === $file ? 'active' : '';
}

function money($amount) {
    return 'R' . number_format((float)$amount, 2);
}
