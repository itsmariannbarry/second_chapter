<?php
// Second Chapter database connection. XAMPP defaults are used.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('BASE_URL', '/second-chapter/');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'second_chapter_db');

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die('<div style="max-width:760px;margin:40px auto;padding:24px;border:1px solid #d8c6b8;border-radius:18px;background:#f8f4ee;font-family:Arial,sans-serif;color:#474747"><h2>Second Chapter database is not connected</h2><p>Please start MySQL in XAMPP, create a database named <strong>second_chapter_db</strong>, and import <strong>setup_database.sql</strong>.</p><p><strong>Error:</strong> ' . htmlspecialchars(mysqli_connect_error(), ENT_QUOTES, 'UTF-8') . '</p></div>');
}

mysqli_set_charset($conn, 'utf8mb4');
?>
