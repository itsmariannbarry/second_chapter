</main>

<footer class="site-footer" id="about">
    <div class="footer-grid">
        <div>
            <a class="brand footer-brand" href="<?= BASE_URL ?>index.php"><span class="brand-mark">S</span><span><strong>Second Chapter</strong><small>Giving Every Book A Second Life</small></span></a>
            <p>Every book deserves a second life, and every student deserves to save.</p>
        </div>
        <div>
            <h4>Browse</h4>
            <a href="<?= BASE_URL ?>books.php">All Books</a>
            <a href="<?= BASE_URL ?>books.php?university=1">By University</a>
            <a href="<?= BASE_URL ?>books.php?sort=newest">New Arrivals</a>
        </div>
        <div>
            <h4>Sell</h4>
            <a href="<?= BASE_URL ?>add-book.php">List a Book</a>
            <a href="<?= BASE_URL ?>my-listings.php">My Listings</a>
            <a href="<?= BASE_URL ?>dashboard.php">My Reading Room</a>
        </div>
        <div>
            <h4>Help</h4>
            <a href="<?= BASE_URL ?>index.php#how-it-works">How It Works</a>
            <a href="<?= BASE_URL ?>index.php#trust">Safety Tips</a>
            <a href="<?= BASE_URL ?>login.php">Account Help</a>
        </div>
    </div>
    <p class="footer-copy">&copy; <?= date('Y') ?> Second Chapter. Made with <span aria-label="love">♥</span> for students, by students.</p>
</footer>
<script src="<?= BASE_URL ?>js/script.js"></script>
</body>
</html>
