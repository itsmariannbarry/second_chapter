<?php
if (!isset($pageTitle)) { $pageTitle = 'Second Chapter'; }
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= clean($pageTitle) ?> | Second Chapter</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Cormorant+Garamond:wght@500;600;700&family=Poppins:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>css/style.css">
</head>
<body>

<!-- Custom cursor -->
<div class="cursor-dot" aria-hidden="true"></div>

<!-- Page loader -->
<div class="page-loader" aria-hidden="true">
    <div class="opening-book"><span></span><span></span></div>
</div>

<!-- ── Leaf confetti — rendered on every page ──────────────── -->
<div class="leaf-layer" aria-hidden="true" id="leafLayer"></div>

<!-- ── Open-book SVG watermark — sits behind all content ───── -->
<div class="page-watermark" aria-hidden="true">
    <svg viewBox="0 0 220 160" xmlns="http://www.w3.org/2000/svg" fill="none">
        <!-- Left page -->
        <path d="M110 20 C90 18 40 22 16 30 L16 138 C40 130 90 128 110 130 Z"
              fill="rgba(126,143,122,0.07)" stroke="rgba(126,143,122,0.13)" stroke-width="1.5"/>
        <!-- Right page -->
        <path d="M110 20 C130 18 180 22 204 30 L204 138 C180 130 130 128 110 130 Z"
              fill="rgba(126,143,122,0.07)" stroke="rgba(126,143,122,0.13)" stroke-width="1.5"/>
        <!-- Spine line -->
        <line x1="110" y1="20" x2="110" y2="130" stroke="rgba(126,143,122,0.18)" stroke-width="2"/>
        <!-- Left page lines -->
        <line x1="30"  y1="55"  x2="98"  y2="53"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <line x1="28"  y1="70"  x2="96"  y2="68"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <line x1="28"  y1="85"  x2="96"  y2="83"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <line x1="28"  y1="100" x2="96"  y2="98"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <!-- Right page lines -->
        <line x1="122" y1="53"  x2="190" y2="55"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <line x1="122" y1="68"  x2="192" y2="70"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <line x1="122" y1="83"  x2="192" y2="85"  stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <line x1="122" y1="98"  x2="192" y2="100" stroke="rgba(126,143,122,0.09)" stroke-width="1"/>
        <!-- Bottom curve / shadow -->
        <path d="M16 138 Q110 148 204 138" stroke="rgba(126,143,122,0.15)" stroke-width="1.5" fill="none"/>
    </svg>
</div>

<!-- ── Navigation ────────────────────────────────────────────── -->
<nav class="site-nav" data-cursor="nav">
    <a class="brand" href="<?= BASE_URL ?>index.php">
        <span class="brand-mark">S</span>
        <span>
            <strong>Second Chapter</strong>
            <small>Every book's new beginning</small>
        </span>
    </a>

    <button class="mobile-menu-button" aria-label="Open menu" aria-controls="navLinks" aria-expanded="false">
        <i class="bi bi-list"></i>
    </button>

    <div class="nav-links" id="navLinks">
        <a class="<?= active_link('books.php') ?>"    href="<?= BASE_URL ?>books.php">Browse</a>
        <a class="<?= active_link('add-book.php') ?>" href="<?= BASE_URL ?>add-book.php">Sell</a>
        <a href="<?= BASE_URL ?>index.php#how-it-works">How It Works</a>
        <a href="<?= BASE_URL ?>index.php#about">About</a>
    </div>

    <div class="nav-actions">
        <a title="Search" href="<?= BASE_URL ?>books.php" data-cursor="listing">
            <i class="bi bi-search"></i>
        </a>
        <a title="Dashboard" href="<?= BASE_URL ?>dashboard.php">
            <i class="bi bi-heart"></i>
        </a>
        <?php if (is_logged_in()): ?>
            <a title="My Listings" href="<?= BASE_URL ?>my-listings.php">
                <i class="bi bi-bag-check"></i>
            </a>
            <?php if (is_admin()): ?>
                <a title="Librarian Office" href="<?= BASE_URL ?>admin/dashboard.php">
                    <i class="bi bi-shield-check"></i>
                </a>
            <?php endif; ?>
            <a title="Profile" href="<?= BASE_URL ?>profile.php">
                <i class="bi bi-person"></i>
            </a>
            <a class="nav-pill" href="<?= BASE_URL ?>logout.php">Logout</a>
        <?php else: ?>
            <a title="Login" href="<?= BASE_URL ?>login.php">
                <i class="bi bi-person"></i>
            </a>
            <a class="nav-pill" href="<?= BASE_URL ?>register.php">Join Free</a>
        <?php endif; ?>
    </div>
</nav>

<?php if (!empty($_SESSION['flash'])): ?>
    <div class="flash flash-<?= clean($_SESSION['flash']['type']) ?>">
        <span class="bookmark-stamp"></span>
        <?= clean($_SESSION['flash']['message']) ?>
        <button type="button" aria-label="Close" onclick="this.parentElement.remove()">&times;</button>
    </div>
    <?php unset($_SESSION['flash']); ?>
<?php endif; ?>

<main>
