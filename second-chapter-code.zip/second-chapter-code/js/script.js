/**
 * Second Chapter — script.js
 * Custom cursor · mobile menu · scroll animations · leaf confetti · file upload
 */
(function () {
  'use strict';

  /* ════════════════════════════════════════════════════════
     1. CUSTOM CURSOR
     ════════════════════════════════════════════════════════ */
  const cursor = document.querySelector('.cursor-dot');

  if (cursor && window.matchMedia('(pointer:fine)').matches) {

    window.addEventListener('mousemove', (e) => {
      cursor.style.left = e.clientX + 'px';
      cursor.style.top  = e.clientY + 'px';
    });

    function resetCursor() {
      cursor.className     = 'cursor-dot';
      cursor.style.opacity = '1';
    }

    /* Standard interactive elements → book cursor */
    document.querySelectorAll('a, button, .btn, .btn-primary, .btn-secondary, .btn-outline')
      .forEach((el) => {
        el.addEventListener('mouseenter', () => cursor.classList.add(el.dataset.cursor || 'button'));
        el.addEventListener('mouseleave', resetCursor);
      });

    /* Book cards → magnifier cursor */
    document.querySelectorAll('.book-card, .book-cover-wrap')
      .forEach((el) => {
        el.addEventListener('mouseenter', () => cursor.classList.add('listing'));
        el.addEventListener('mouseleave', resetCursor);
      });

    /* Nav area → page-flip cursor */
    document.querySelectorAll('[data-cursor="nav"], .nav-links a')
      .forEach((el) => {
        el.addEventListener('mouseenter', () => cursor.classList.add('nav'));
        el.addEventListener('mouseleave', resetCursor);
      });

    /* Upload drop zone → HIDE custom cursor entirely so the OS drag cursor shows */
    document.querySelectorAll('.upload-drop')
      .forEach((el) => {
        el.addEventListener('mouseenter', () => {
          cursor.style.opacity = '0';
        });
        el.addEventListener('mouseleave', resetCursor);
      });
  }

  /* ════════════════════════════════════════════════════════
     2. MOBILE MENU
     ════════════════════════════════════════════════════════ */
  const menuBtn  = document.querySelector('.mobile-menu-button');
  const navLinks = document.querySelector('#navLinks');

  if (menuBtn && navLinks) {
    menuBtn.addEventListener('click', () => {
      const open = navLinks.classList.toggle('open');
      menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
      menuBtn.innerHTML = open ? '<i class="bi bi-x-lg"></i>' : '<i class="bi bi-list"></i>';
    });
    navLinks.querySelectorAll('a').forEach((link) => {
      link.addEventListener('click', () => {
        navLinks.classList.remove('open');
        menuBtn.setAttribute('aria-expanded', 'false');
        menuBtn.innerHTML = '<i class="bi bi-list"></i>';
      });
    });
  }

  /* ════════════════════════════════════════════════════════
     3. SCROLL FADE-IN
     ════════════════════════════════════════════════════════ */
  const io = new IntersectionObserver(
    (entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('show'); io.unobserve(e.target); } }),
    { threshold: 0.1 }
  );
  document.querySelectorAll('.fade-in, .book-card, .paper-card, .mini-stat, .spine')
    .forEach((el) => io.observe(el));

  /* ════════════════════════════════════════════════════════
     4. FILE UPLOAD PREVIEW
     ════════════════════════════════════════════════════════ */
  document.querySelectorAll('input[type="file"]').forEach((input) => {
    input.addEventListener('change', () => {
      const box = input.closest('.upload-drop');
      if (box && input.files.length) box.classList.add('has-file');
    });
  });

  /* ════════════════════════════════════════════════════════
     5. AUTO-DISMISS FLASH
     ════════════════════════════════════════════════════════ */
  const flash = document.querySelector('.flash');
  if (flash) {
    setTimeout(() => {
      flash.style.transition = 'opacity .5s';
      flash.style.opacity = '0';
      setTimeout(() => flash.remove(), 520);
    }, 5000);
  }

  /* ════════════════════════════════════════════════════════
     6. LEAF CONFETTI
     Leaf-shaped SVG paths float gently across every page.
     ════════════════════════════════════════════════════════ */
  const leafContainer = document.getElementById('leafLayer');
  if (!leafContainer) return;

  /* Leaf path variants — two slightly different leaf silhouettes */
  const LEAF_PATHS = [
    /* rounded leaf pointing top-right */
    'M12 2C12 2 6 7 6 13C6 16.87 9.13 20 13 20C13 20 19 15 19 9C19 5.13 15.87 2 12 2Z',
    /* slender leaf */
    'M12 3C12 3 7 8 7 13.5C7 17.09 9.91 20 13.5 20C13.5 20 18 15 18 9.5C18 5.91 15.09 3 12 3Z',
    /* rounder leaf */
    'M11 2C11 2 5 7.5 5 13C5 17.42 8.58 21 13 21C13 21 19 15.5 19 10C19 5.58 15.42 2 11 2Z',
  ];

  /* Colour pool — sage greens and gold, very low opacity */
  const COLOURS = [
    'rgba(126,143,122,0.28)',
    'rgba(95,109,93,0.22)',
    'rgba(214,185,140,0.30)',
    'rgba(159,175,155,0.25)',
    'rgba(138,159,134,0.20)',
  ];

  const TOTAL_LEAVES = 14;
  const vw = window.innerWidth;
  const vh = window.innerHeight;

  function randBetween(a, b) { return a + Math.random() * (b - a); }

  function createLeaf(index) {
    const ns   = 'http://www.w3.org/2000/svg';
    const wrap = document.createElementNS(ns, 'svg');
    const size = randBetween(14, 30);          /* px */
    wrap.setAttribute('width',   size);
    wrap.setAttribute('height',  size);
    wrap.setAttribute('viewBox', '0 0 24 24');
    wrap.setAttribute('fill',    'none');
    wrap.style.cssText = 'position:absolute;pointer-events:none;';

    const path = document.createElementNS(ns, 'path');
    path.setAttribute('d',    LEAF_PATHS[index % LEAF_PATHS.length]);
    path.setAttribute('fill', COLOURS[index % COLOURS.length]);
    wrap.appendChild(path);
    leafContainer.appendChild(wrap);

    animateLeaf(wrap);
    return wrap;
  }

  function animateLeaf(el) {
    const startX   = randBetween(0, vw);
    const startY   = randBetween(-80, -20);         /* start above viewport */
    const endX     = startX + randBetween(-180, 180);
    const endY     = vh + randBetween(40, 120);     /* land below viewport */
    const duration = randBetween(12000, 24000);     /* ms */
    const delay    = randBetween(0, 8000);          /* stagger */
    const startRot = randBetween(0, 360);
    const endRot   = startRot + randBetween(90, 270);

    /* Keyframe animation via Web Animations API (no deps, works everywhere) */
    el.style.left      = startX + 'px';
    el.style.top       = startY + 'px';
    el.style.transform = `rotate(${startRot}deg)`;

    const anim = el.animate(
      [
        { transform: `translate(0px, 0px)         rotate(${startRot}deg)`, opacity: 0    },
        { transform: `translate(${(endX-startX)*0.3}px, ${endY*0.3}px) rotate(${startRot + (endRot-startRot)*0.3}deg)`, opacity: 1,   offset: 0.08  },
        { transform: `translate(${endX-startX}px,  ${endY}px)           rotate(${endRot}deg)`,  opacity: 0.15 },
      ],
      {
        duration,
        delay,
        easing:   'ease-in-out',
        fill:     'forwards',
      }
    );

    /* Loop forever: on finish, reset and restart */
    anim.onfinish = () => {
      el.style.left = randBetween(0, vw) + 'px';
      el.style.top  = randBetween(-80, -20) + 'px';
      animateLeaf(el);
    };
  }

  /* Spawn leaves staggered so they don't all appear at once */
  for (let i = 0; i < TOTAL_LEAVES; i++) {
    createLeaf(i);
  }

})();
