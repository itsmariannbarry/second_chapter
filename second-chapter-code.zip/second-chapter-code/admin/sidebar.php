<?php
/* Admin sidebar — included by all admin pages */
$pendingSidebar = (int)mysqli_fetch_assoc(mysqli_query($conn,
    "SELECT COUNT(*) AS n FROM books WHERE status='pending'"
))['n'];
?>
<aside class="sidebar-card">
    <p class="sidebar-label">Librarian's Office</p>
    <a href="dashboard.php"  class="<?= basename($_SERVER['PHP_SELF']) === 'dashboard.php'  ? 'active' : '' ?>">
        <i class="bi bi-speedometer2"></i> Overview
    </a>
    <a href="listings.php"   class="<?= basename($_SERVER['PHP_SELF']) === 'listings.php'   ? 'active' : '' ?>">
        <i class="bi bi-journal-check"></i> Manage Listings
        <?php if ($pendingSidebar > 0): ?>
            <span class="badge-pending"><?= $pendingSidebar ?></span>
        <?php endif; ?>
    </a>
    <a href="users.php"      class="<?= basename($_SERVER['PHP_SELF']) === 'users.php'      ? 'active' : '' ?>">
        <i class="bi bi-people"></i> Manage Users
    </a>
    <a href="settings.php"   class="<?= basename($_SERVER['PHP_SELF']) === 'settings.php'   ? 'active' : '' ?>">
        <i class="bi bi-gear"></i> Settings
    </a>
    <a href="../index.php">
        <i class="bi bi-house"></i> Main Website
    </a>
</aside>
