<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_admin();

$pageTitle = "The Librarian's Office";

$totalUsers = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM users"))['n'];
$totalBooks = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books"))['n'];
$pending    = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='pending'"))['n'];
$approved   = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='approved'"))['n'];
$rejected   = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='rejected'"))['n'];
$sold       = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='sold'"))['n'];

$pendingBooks = mysqli_fetch_all(mysqli_query($conn,
    "SELECT b.*, uni.short_name,
            CONCAT(u.first_name,' ',u.last_name) AS seller_name,
            u.email AS seller_email
     FROM books b
     JOIN users u ON b.seller_id = u.user_id
     LEFT JOIN universities uni ON b.university_id = uni.university_id
     WHERE b.status = 'pending'
     ORDER BY b.created_at ASC"
), MYSQLI_ASSOC);

$recent = mysqli_fetch_all(mysqli_query($conn,
    "SELECT b.*, CONCAT(u.first_name,' ',u.last_name) AS seller_name
     FROM books b
     JOIN users u ON b.seller_id = u.user_id
     WHERE b.status != 'pending'
     ORDER BY b.created_at DESC LIMIT 10"
), MYSQLI_ASSOC);

include '../includes/header.php';
?>
<section class="admin-shell">
  <div class="container dashboard-grid">

    <?php include 'sidebar.php'; ?>

    <div>
      <div class="chapter" style="text-align:left;margin:0 0 28px">
        <span>The Librarian's Office</span>
        <h2>Admin Dashboard</h2>
        <p>Review pending listings, manage users and monitor the platform.</p>
      </div>

      <!-- Stats — 6 columns -->
      <div class="mini-stats" style="grid-template-columns:repeat(6,1fr);margin-bottom:36px">
        <div class="mini-stat"><strong><?= $totalUsers ?></strong><span>Users</span></div>
        <div class="mini-stat"><strong><?= $totalBooks ?></strong><span>Total Books</span></div>
        <div class="mini-stat mini-stat--warning"><strong><?= $pending ?></strong><span>Pending</span></div>
        <div class="mini-stat mini-stat--success"><strong><?= $approved ?></strong><span>Approved</span></div>
        <div class="mini-stat mini-stat--muted"><strong><?= $rejected ?></strong><span>Rejected</span></div>
        <div class="mini-stat mini-stat--sold"><strong><?= $sold ?></strong><span>Sold</span></div>
      </div>

      <!-- Pending approvals -->
      <?php if ($pendingBooks): ?>
        <div class="admin-section-header">
          <h3><i class="bi bi-hourglass-split"></i> Awaiting Approval <span class="badge-pending"><?= count($pendingBooks) ?></span></h3>
          <p>These listings are invisible to students until you approve them.</p>
        </div>
        <div class="table-card" style="margin-bottom:36px">
          <table>
            <thead>
              <tr><th>Book</th><th>Seller</th><th>University</th><th>Price</th><th>Condition</th><th>Listed</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php foreach ($pendingBooks as $b): ?>
                <tr class="row-pending">
                  <td>
                    <strong><?= clean($b['title']) ?></strong>
                    <?php if ($b['module_code']): ?><br><small class="text-muted"><?= clean($b['module_code']) ?></small><?php endif; ?>
                    <?php if ($b['author']):       ?><br><small class="text-muted"><?= clean($b['author'])       ?></small><?php endif; ?>
                  </td>
                  <td><?= clean($b['seller_name']) ?><br><small class="text-muted"><?= clean($b['seller_email']) ?></small></td>
                  <td><?= clean($b['short_name'] ?? '—') ?></td>
                  <td><strong><?= money($b['price']) ?></strong></td>
                  <td><span class="status-tag status-approved"><?= clean($b['condition_grade']) ?></span></td>
                  <td style="font-size:13px;color:var(--muted);white-space:nowrap"><?= date('d M Y', strtotime($b['created_at'])) ?></td>
                  <td style="white-space:nowrap">
                    <a class="btn-approve" href="listings.php?action=approved&id=<?= (int)$b['book_id'] ?>&from=dashboard"><i class="bi bi-check-lg"></i> Approve</a>
                    <a class="btn-reject"  href="listings.php?action=rejected&id=<?= (int)$b['book_id'] ?>&from=dashboard"><i class="bi bi-x-lg"></i> Reject</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      <?php else: ?>
        <div class="empty-approval" style="margin-bottom:36px">
          <i class="bi bi-check-circle"></i>
          <p>All caught up — no listings are waiting for approval right now.</p>
        </div>
      <?php endif; ?>

      <!-- Recent activity -->
      <div class="admin-section-header">
        <h3><i class="bi bi-clock-history"></i> Recent Activity</h3>
        <p>The last 10 listings that were approved, rejected or sold.</p>
      </div>
      <div class="table-card">
        <table>
          <thead><tr><th>Book</th><th>Seller</th><th>Price</th><th>Status</th><th>Date</th><th>Re-evaluate</th></tr></thead>
          <tbody>
            <?php if (!$recent): ?>
              <tr><td colspan="6" style="color:var(--muted);text-align:center;padding:28px">No activity yet.</td></tr>
            <?php endif; ?>
            <?php foreach ($recent as $b): ?>
              <tr>
                <td><strong><?= clean($b['title']) ?></strong></td>
                <td><?= clean($b['seller_name']) ?></td>
                <td><?= money($b['price']) ?></td>
                <td><span class="status-tag status-<?= clean($b['status']) ?>"><?= ucfirst(clean($b['status'])) ?></span></td>
                <td style="font-size:13px;color:var(--muted)"><?= date('d M Y', strtotime($b['created_at'])) ?></td>
                <td style="white-space:nowrap">
                  <?php if ($b['status'] !== 'approved'): ?><a class="btn-approve" href="listings.php?action=approved&id=<?= (int)$b['book_id'] ?>&from=dashboard"><i class="bi bi-check-lg"></i> Approve</a><?php endif; ?>
                  <?php if ($b['status'] !== 'rejected'): ?><a class="btn-reject"  href="listings.php?action=rejected&id=<?= (int)$b['book_id'] ?>&from=dashboard"><i class="bi bi-x-lg"></i> Reject</a><?php endif; ?>
                  <?php if ($b['status'] === 'approved'): ?><a class="btn-sold"   href="listings.php?action=sold&id=<?= (int)$b['book_id'] ?>&from=dashboard"><i class="bi bi-bag-check"></i> Sold</a><?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
<?php include '../includes/footer.php'; ?>
