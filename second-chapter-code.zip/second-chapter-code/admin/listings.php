<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_admin();

$pageTitle = 'Manage Listings';

/* ── Handle action (approve / reject / sold / pending) ───────── */
if (isset($_GET['action'], $_GET['id'])) {
    $id     = (int)$_GET['id'];
    $action = $_GET['action'];
    if (in_array($action, ['approved','pending','rejected','sold'], true)) {
        $stmt = mysqli_prepare($conn, "UPDATE books SET status = ? WHERE book_id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $action, $id);
        mysqli_stmt_execute($stmt);
        $labels = [
            'approved' => 'Listing approved — now visible to students.',
            'rejected' => 'Listing rejected.',
            'pending'  => 'Listing moved back to pending.',
            'sold'     => 'Listing marked as sold.',
        ];
        flash('success', $labels[$action]);
    }
    $from = $_GET['from'] ?? 'listings';
    redirect($from === 'dashboard' ? 'admin/dashboard.php' : 'admin/listings.php');
}

/* ── Status filter ──────────────────────────────────────────── */
$filterStatus   = $_GET['status'] ?? 'pending';
$allowedFilters = ['pending','approved','rejected','sold','all'];
if (!in_array($filterStatus, $allowedFilters, true)) $filterStatus = 'pending';

$where = $filterStatus !== 'all' ? "WHERE b.status = '$filterStatus'" : '';

$books = mysqli_fetch_all(mysqli_query($conn,
    "SELECT b.*, CONCAT(u.first_name,' ',u.last_name) AS seller_name, uni.short_name
     FROM books b
     JOIN users u ON b.seller_id = u.user_id
     LEFT JOIN universities uni ON b.university_id = uni.university_id
     $where
     ORDER BY b.created_at DESC"
), MYSQLI_ASSOC);

$counts = [];
foreach (['pending','approved','rejected','sold'] as $s) {
    $counts[$s] = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='$s'"))['n'];
}
$counts['all'] = array_sum($counts);

include '../includes/header.php';
?>
<section class="admin-shell">
  <div class="container dashboard-grid">

    <?php include 'sidebar.php'; ?>

    <div>
      <div class="chapter" style="text-align:left;margin:0 0 24px">
        <span>Approval Desk</span>
        <h2>Manage Listings</h2>
        <p>Review, approve or reject student book listings.</p>
      </div>

      <!-- Status tabs -->
      <div class="status-tabs">
        <?php foreach (['pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected','sold'=>'Sold','all'=>'All'] as $key => $label): ?>
          <a href="?status=<?= $key ?>" class="status-tab <?= $filterStatus === $key ? 'active' : '' ?>">
            <?= $label ?> <span class="tab-count"><?= $counts[$key] ?></span>
          </a>
        <?php endforeach; ?>
      </div>

      <div class="table-card">
        <table>
          <thead><tr><th>Book</th><th>Seller</th><th>University</th><th>Price</th><th>Status</th><th>Listed</th><th>Actions</th></tr></thead>
          <tbody>
            <?php if (!$books): ?>
              <tr><td colspan="7" style="color:var(--muted);text-align:center;padding:32px">No listings in this category.</td></tr>
            <?php endif; ?>
            <?php foreach ($books as $b): ?>
              <tr class="row-<?= clean($b['status']) ?>">
                <td>
                  <strong><?= clean($b['title']) ?></strong>
                  <?php if ($b['module_code']): ?><br><small class="text-muted"><?= clean($b['module_code']) ?></small><?php endif; ?>
                </td>
                <td><?= clean($b['seller_name']) ?></td>
                <td><?= clean($b['short_name'] ?? '—') ?></td>
                <td><?= money($b['price']) ?></td>
                <td><span class="status-tag status-<?= clean($b['status']) ?>"><?= ucfirst(clean($b['status'])) ?></span></td>
                <td style="font-size:13px;color:var(--muted);white-space:nowrap"><?= date('d M Y', strtotime($b['created_at'])) ?></td>
                <td style="white-space:nowrap">
                  <?php if ($b['status'] !== 'approved'): ?><a class="btn-approve" href="?action=approved&id=<?= (int)$b['book_id'] ?>"><i class="bi bi-check-lg"></i> Approve</a><?php endif; ?>
                  <?php if ($b['status'] !== 'rejected'): ?><a class="btn-reject"  href="?action=rejected&id=<?= (int)$b['book_id'] ?>"><i class="bi bi-x-lg"></i> Reject</a><?php endif; ?>
                  <?php if ($b['status'] === 'approved'): ?><a class="btn-sold"   href="?action=sold&id=<?= (int)$b['book_id'] ?>"><i class="bi bi-bag-check"></i> Sold</a><?php endif; ?>
                  <?php if ($b['status'] !== 'pending'):  ?><a class="btn-outline btn-small" href="?action=pending&id=<?= (int)$b['book_id'] ?>" style="margin-left:2px"><i class="bi bi-arrow-counterclockwise"></i> Reset</a><?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
<?php include '../includes/footer.php'; ?>
