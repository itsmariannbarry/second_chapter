<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_admin();

$pageTitle = 'Admin Settings';
$errors    = [];
$success   = false;

/* ── Change admin password ──────────────────────────────────── */
if (isset($_POST['action']) && $_POST['action'] === 'change_password') {
    $currentPw  = $_POST['current_password']  ?? '';
    $newPw      = $_POST['new_password']       ?? '';
    $confirmPw  = $_POST['confirm_password']   ?? '';

    $adminUser = mysqli_fetch_assoc(mysqli_prepare_run($conn,
        "SELECT * FROM users WHERE user_id = ?", 'i', (int)$_SESSION['user_id']
    ));

    if (!password_verify($currentPw, $adminUser['password']) && $currentPw !== $adminUser['password']) {
        $errors[] = 'Current password is incorrect.';
    }
    if (strlen($newPw) < 8) {
        $errors[] = 'New password must be at least 8 characters.';
    }
    if ($newPw !== $confirmPw) {
        $errors[] = 'New passwords do not match.';
    }
    if (!$errors) {
        $hash = password_hash($newPw, PASSWORD_DEFAULT);
        $stmt = mysqli_prepare($conn, "UPDATE users SET password = ? WHERE user_id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $hash, (int)$_SESSION['user_id']);
        mysqli_stmt_execute($stmt);
        flash('success', 'Password updated successfully.');
        redirect('admin/settings.php');
    }
}

/* ── Bulk-delete rejected listings ─────────────────────────── */
if (isset($_POST['action']) && $_POST['action'] === 'purge_rejected') {
    mysqli_query($conn, "DELETE FROM books WHERE status = 'rejected'");
    flash('success', 'All rejected listings have been removed.');
    redirect('admin/settings.php');
}

/* ── Bulk-delete sold listings ──────────────────────────────── */
if (isset($_POST['action']) && $_POST['action'] === 'purge_sold') {
    mysqli_query($conn, "DELETE FROM books WHERE status = 'sold'");
    flash('success', 'All sold listings have been removed.');
    redirect('admin/settings.php');
}

/* Helper: run a prepared statement and return its result */
function mysqli_prepare_run($conn, $sql, $types, ...$params) {
    $stmt = mysqli_prepare($conn, $sql);
    if ($types && $params) mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    return mysqli_stmt_get_result($stmt);
}

/* Stats for display */
$rejectedCount = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='rejected'"))['n'];
$soldCount     = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books WHERE status='sold'"))['n'];
$userCount     = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM users"))['n'];
$totalBooks    = (int)mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS n FROM books"))['n'];

include '../includes/header.php';
?>
<section class="admin-shell">
  <div class="container dashboard-grid">

    <?php include 'sidebar.php'; ?>

    <div>
      <div class="chapter" style="text-align:left;margin:0 0 28px">
        <span>The Librarian's Office</span>
        <h2>Settings</h2>
        <p>Manage your admin account and platform housekeeping.</p>
      </div>

      <!-- ── Platform info ──────────────────────────────────── -->
      <div class="admin-settings-grid">

        <!-- Platform overview card -->
        <div class="settings-card">
          <h3><i class="bi bi-bar-chart-line"></i> Platform Overview</h3>
          <div class="settings-stat-row">
            <div class="settings-stat"><strong><?= $userCount ?></strong><span>Total Users</span></div>
            <div class="settings-stat"><strong><?= $totalBooks ?></strong><span>Total Listings</span></div>
            <div class="settings-stat"><strong><?= $rejectedCount ?></strong><span>Rejected</span></div>
            <div class="settings-stat"><strong><?= $soldCount ?></strong><span>Sold</span></div>
          </div>
        </div>

        <!-- Admin account card -->
        <div class="settings-card">
          <h3><i class="bi bi-person-lock"></i> Admin Account</h3>
          <p class="settings-info">
            Logged in as <strong><?= clean($_SESSION['first_name'] . ' ' . $_SESSION['last_name']) ?></strong><br>
            <span class="text-muted"><?= clean($_SESSION['email']) ?></span>
          </p>
          <p class="settings-note"><i class="bi bi-lock-fill"></i> Admin access is restricted to <strong><?= clean(ADMIN_EMAIL) ?></strong> only.</p>
        </div>

        <!-- Change password card -->
        <div class="settings-card settings-card--full">
          <h3><i class="bi bi-key"></i> Change Password</h3>

          <?php if ($errors): ?>
            <div class="error-list">
              <?php foreach ($errors as $e): ?><p><?= clean($e) ?></p><?php endforeach; ?>
            </div>
          <?php endif; ?>

          <form method="post" class="settings-form">
            <input type="hidden" name="action" value="change_password">
            <div class="settings-fields">
              <div class="field">
                <label>Current Password</label>
                <input type="password" name="current_password" required placeholder="Your current password">
              </div>
              <div class="field">
                <label>New Password</label>
                <input type="password" name="new_password" required placeholder="At least 8 characters">
              </div>
              <div class="field">
                <label>Confirm New Password</label>
                <input type="password" name="confirm_password" required placeholder="Repeat new password">
              </div>
            </div>
            <button class="btn-primary btn-small" type="submit" style="margin-top:18px">
              <i class="bi bi-check-lg"></i> Update Password
            </button>
          </form>
        </div>

        <!-- Housekeeping card -->
        <div class="settings-card settings-card--full">
          <h3><i class="bi bi-trash3"></i> Housekeeping</h3>
          <p class="settings-info">These actions permanently delete listings from the database. They cannot be undone.</p>

          <div class="housekeeping-row">
            <div class="housekeeping-item">
              <div>
                <strong>Purge rejected listings</strong>
                <p class="text-muted" style="margin:4px 0 0;font-size:13px">Remove all <?= $rejectedCount ?> rejected listing<?= $rejectedCount !== 1 ? 's' : '' ?> permanently.</p>
              </div>
              <form method="post" onsubmit="return confirm('Delete all <?= $rejectedCount ?> rejected listings permanently?')">
                <input type="hidden" name="action" value="purge_rejected">
                <button class="btn-reject btn-small" type="submit" <?= $rejectedCount === 0 ? 'disabled style="opacity:.4"' : '' ?>>
                  <i class="bi bi-trash3"></i> Delete Rejected (<?= $rejectedCount ?>)
                </button>
              </form>
            </div>

            <div class="housekeeping-item">
              <div>
                <strong>Purge sold listings</strong>
                <p class="text-muted" style="margin:4px 0 0;font-size:13px">Remove all <?= $soldCount ?> sold listing<?= $soldCount !== 1 ? 's' : '' ?> permanently.</p>
              </div>
              <form method="post" onsubmit="return confirm('Delete all <?= $soldCount ?> sold listings permanently?')">
                <input type="hidden" name="action" value="purge_sold">
                <button class="btn-reject btn-small" type="submit" <?= $soldCount === 0 ? 'disabled style="opacity:.4"' : '' ?>>
                  <i class="bi bi-trash3"></i> Delete Sold (<?= $soldCount ?>)
                </button>
              </form>
            </div>
          </div>
        </div>

      </div><!-- /admin-settings-grid -->
    </div>
  </div>
</section>
<?php include '../includes/footer.php'; ?>
