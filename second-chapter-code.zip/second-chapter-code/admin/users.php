<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
require_admin();

$pageTitle = 'Manage Users';

if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    if ($id !== (int)$_SESSION['user_id']) {
        mysqli_query($conn, "UPDATE users SET is_active = IF(is_active=1,0,1) WHERE user_id=$id");
        flash('success', 'User status updated.');
    }
    redirect('admin/users.php');
}

$users = mysqli_fetch_all(mysqli_query($conn,
    "SELECT u.*, r.role_name, uni.short_name,
            (SELECT COUNT(*) FROM books WHERE seller_id = u.user_id) AS book_count
     FROM users u
     JOIN roles r ON u.role_id = r.role_id
     LEFT JOIN universities uni ON u.university_id = uni.university_id
     ORDER BY u.created_at DESC"
), MYSQLI_ASSOC);

include '../includes/header.php';
?>
<section class="admin-shell">
  <div class="container dashboard-grid">

    <?php include 'sidebar.php'; ?>

    <div>
      <div class="chapter" style="text-align:left;margin:0 0 24px">
        <span>Library Cards</span>
        <h2>Manage Users</h2>
        <p><?= count($users) ?> registered account<?= count($users) !== 1 ? 's' : '' ?> on the platform.</p>
      </div>

      <div class="table-card">
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>University</th><th>Listings</th><th>Role</th><th>Joined</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>
            <?php foreach ($users as $u): ?>
              <tr>
                <td><strong><?= clean($u['first_name'] . ' ' . $u['last_name']) ?></strong></td>
                <td style="font-size:13px;color:var(--muted)"><?= clean($u['email']) ?></td>
                <td><?= clean($u['short_name'] ?? '—') ?></td>
                <td style="text-align:center"><?= (int)$u['book_count'] ?></td>
                <td><span class="status-tag status-<?= $u['role_name'] === 'admin' ? 'approved' : 'role-user' ?>"><?= clean($u['role_name']) ?></span></td>
                <td style="font-size:13px;color:var(--muted);white-space:nowrap"><?= date('d M Y', strtotime($u['created_at'])) ?></td>
                <td><span class="status-tag <?= $u['is_active'] ? 'status-approved' : 'status-rejected' ?>"><?= $u['is_active'] ? 'Active' : 'Disabled' ?></span></td>
                <td>
                  <?php if ((int)$u['user_id'] !== (int)$_SESSION['user_id']): ?>
                    <a class="<?= $u['is_active'] ? 'btn-reject' : 'btn-approve' ?>" href="?toggle=<?= (int)$u['user_id'] ?>">
                      <?= $u['is_active'] ? '<i class="bi bi-slash-circle"></i> Disable' : '<i class="bi bi-check-circle"></i> Enable' ?>
                    </a>
                  <?php else: ?>
                    <span style="color:var(--muted);font-size:13px">You</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</section>
<?php include '../includes/footer.php'; ?>
